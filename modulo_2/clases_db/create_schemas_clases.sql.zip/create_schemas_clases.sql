CREATE SCHEMA `tienda` ;
CREATE SCHEMA `sakila` ;
CREATE SCHEMA `world` ;
CREATE SCHEMA `leccion-1-sql` ;
CREATE SCHEMA `leccion-2-sql` ;
CREATE SCHEMA `leccion-3-sql` ;
CREATE SCHEMA `leccion-4-sql` ;
CREATE SCHEMA `leccion-5-sql` ;
CREATE SCHEMA `leccion-6-sql` ;
CREATE SCHEMA `leccion-7-sql` ;
CREATE SCHEMA `leccion-8-sql` ;
CREATE SCHEMA `leccion-9-sql` ;
CREATE SCHEMA `leccion-10-sql` ;
CREATE SCHEMA `leccion-11-sql` ;
CREATE SCHEMA `leccion-12-sql` ;
CREATE SCHEMA `leccion-13-sql` ;
CREATE SCHEMA `leccion-14-sql` ;

